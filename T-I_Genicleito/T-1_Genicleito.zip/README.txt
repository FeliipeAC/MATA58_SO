Instruções para compilação (Segue os padrões):

gcc -pthread -Wall T-1_Genicleito.c

Para executar basta seguir os moldes padrões:
./a.out
